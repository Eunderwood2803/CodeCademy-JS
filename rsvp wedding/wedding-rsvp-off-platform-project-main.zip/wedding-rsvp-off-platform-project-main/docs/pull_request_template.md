Elizabeth and Philip are delighted that you are planning on coming to their wedding! 
Before submitting this PR, please make sure:

- [ ] Your name is added to the list of guests with proper spelling.
- [ ] You have added the correct number of guests that are coming with and including you.
- [ ] The format of the markdown table in the `guests.md` file is valid.
